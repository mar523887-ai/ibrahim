from flask import Flask, request, jsonify
from flask_cors import CORS
import json
from datetime import datetime
import hashlib

app = Flask(__name__)
CORS(app)  # تمكين CORS لجميع المصادر

# إعدادات قاعدة البيانات
SPREADSHEET_ID = '1zIe1SIQSG0SjTHzvcSDTLBNkjPfqo-11KEQ4syrKVuk'
SHEETS_API_KEY = 'YOUR_API_KEY_HERE'  # يجب الحصول عليه من Google Cloud Console

# أسماء الأوراق في Google Sheets
SHEETS = {
    'inventory': 'المخزون',
    'incoming': 'الواردات', 
    'outgoing': 'الصادرات',
    'users': 'المستخدمين',
    'alerts': 'التنبيهات',
    'reports': 'التقارير',
    'login_attempts': 'محاولات الدخول',
    'backup': 'النسخ الاحتياطي',
    'log': 'السجل'
}

# بيانات وهمية للاختبار (نفس البيانات من JavaScript)
mock_data = {
    'users': [
        {
            'id': 1,
            'fullName': 'أحمد محمد',
            'username': 'admin',
            'password': 'admin123',
            'role': 'مدير',
            'status': 'نشط',
            'email': 'admin@company.com',
            'phone': '+966501234567',
            'createdAt': '2024-01-01',
            'lastLogin': '2024-08-06',
            'permissions': 'جميع الصلاحيات',
            'expiryDate': '2025-12-31',
            'lastPasswordChange': '2024-06-01',
            'failedLoginAttempts': 0
        }
    ],
    'inventory': [
        {
            'id': 1,
            'name': 'أحذية رياضية',
            'category': 'أحذية',
            'brand': 'نايك',
            'size': '42',
            'color': 'أسود',
            'quantity': 25,
            'minQuantity': 10,
            'maxQuantity': 100,
            'location': 'المستودع A - الرف 1',
            'supplier': 'شركة الرياضة المحدودة',
            'cost': 120.00,
            'price': 180.00,
            'currency': 'SYP',
            'barcode': '1234567890123',
            'description': 'أحذية رياضية عالية الجودة',
            'status': 'متوفر',
            'createdAt': '2024-07-15',
            'updatedAt': '2024-08-01',
            'expiryDate': null,
            'weight': 0.8,
            'dimensions': '30x20x15',
            'tags': 'رياضة,أحذية,نايك'
        },
        {
            'id': 2,
            'name': 'قميص قطني',
            'category': 'ملابس',
            'brand': 'أديداس',
            'size': 'L',
            'color': 'أبيض',
            'quantity': 5,
            'minQuantity': 15,
            'maxQuantity': 50,
            'location': 'المستودع B - الرف 3',
            'supplier': 'مصنع النسيج الحديث',
            'cost': 45.00,
            'price': 75.00,
            'currency': 'SYP',
            'barcode': '9876543210987',
            'description': 'قميص قطني مريح',
            'status': 'مخزون منخفض',
            'createdAt': '2024-07-20',
            'updatedAt': '2024-08-03',
            'expiryDate': null,
            'weight': 0.3,
            'dimensions': '25x35x2',
            'tags': 'ملابس,قطن,أديداس'
        }
    ],
    'incoming': [
        {
            'id': 1,
            'itemId': 1,
            'itemName': 'أحذية رياضية',
            'supplier': 'شركة الرياضة المحدودة',
            'size': '42',
            'brand': 'نايك',
            'quantity': 50,
            'price': 150.00,
            'date': '2024-08-01',
            'currency': 'SYP',
            'exchangeRate': 1.0,
            'paymentMethod': 'تحويل بنكي',
            'invoiceNumber': 'INV-2024-001',
            'notes': 'شحنة جديدة',
            'status': 'مكتمل',
            'receivedBy': 'أحمد محمد',
            'qualityCheck': 'مقبول',
            'storageLocation': 'المستودع A - الرف 1',
            'expiryDate': null,
            'batchNumber': 'BATCH-001',
            'totalCost': 7500.00
        }
    ],
    'outgoing': [
        {
            'id': 1,
            'itemId': 1,
            'itemName': 'أحذية رياضية',
            'customer': 'متجر الرياضة الذهبي',
            'size': '42',
            'brand': 'نايك',
            'quantity': 25,
            'price': 200.00,
            'date': '2024-08-03',
            'currency': 'TRY',
            'exchangeRate': 1.0,
            'paymentMethod': 'نقد',
            'invoiceNumber': 'OUT-2024-001',
            'notes': 'بيع بالجملة',
            'status': 'مكتمل',
            'soldBy': 'أحمد محمد',
            'deliveryMethod': 'توصيل مباشر',
            'customerPhone': '+966501234567',
            'customerAddress': 'الرياض، المملكة العربية السعودية',
            'profit': 2000.00,
            'totalRevenue': 5000.00
        }
    ],
    'alerts': [
        {
            'id': 1,
            'type': 'مخزون منخفض',
            'message': 'قميص قطني - الكمية أقل من الحد الأدنى',
            'itemId': 2,
            'itemName': 'قميص قطني',
            'currentQuantity': 5,
            'minQuantity': 15,
            'priority': 'عالية',
            'status': 'نشط',
            'createdAt': '2024-08-06',
            'acknowledgedBy': null,
            'resolvedAt': null,
            'category': 'مخزون',
            'action': 'طلب شراء جديد'
        },
        {
            'id': 2,
            'type': 'تنبيه نظام',
            'message': 'تم تسجيل دخول جديد من IP غير معروف',
            'priority': 'متوسطة',
            'status': 'نشط',
            'createdAt': '2024-08-06',
            'acknowledgedBy': null,
            'resolvedAt': null,
            'category': 'أمان',
            'action': 'مراجعة السجل'
        }
    ]
}

def hash_password(password):
    """تشفير كلمة المرور"""
    return hashlib.sha256(password.encode()).hexdigest()

def verify_password(password, hashed):
    """التحقق من كلمة المرور"""
    return hash_password(password) == hashed

def log_activity(user_id, action, details):
    """تسجيل النشاط"""
    log_entry = {
        'id': len(mock_data.get('log', [])) + 1,
        'userId': user_id,
        'action': action,
        'details': details,
        'timestamp': datetime.now().isoformat(),
        'ipAddress': request.remote_addr,
        'userAgent': request.headers.get('User-Agent', '')
    }
    if 'log' not in mock_data:
        mock_data['log'] = []
    mock_data['log'].append(log_entry)

# Routes للمصادقة
@app.route('/api/auth/login', methods=['POST'])
def login():
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'success': False, 'message': 'اسم المستخدم وكلمة المرور مطلوبان'}), 400
        
        # البحث عن المستخدم
        user = None
        for u in mock_data['users']:
            if u['username'] == username:
                user = u
                break
        
        if not user:
            log_activity(None, 'فشل تسجيل الدخول', f'اسم مستخدم غير موجود: {username}')
            return jsonify({'success': False, 'message': 'اسم المستخدم أو كلمة المرور غير صحيحة'}), 401
        
        # التحقق من كلمة المرور (للاختبار نستخدم مقارنة مباشرة)
        if user['password'] != password:
            user['failedLoginAttempts'] = user.get('failedLoginAttempts', 0) + 1
            log_activity(user['id'], 'فشل تسجيل الدخول', f'كلمة مرور خاطئة للمستخدم: {username}')
            return jsonify({'success': False, 'message': 'اسم المستخدم أو كلمة المرور غير صحيحة'}), 401
        
        # تحديث آخر تسجيل دخول
        user['lastLogin'] = datetime.now().strftime('%Y-%m-%d')
        user['failedLoginAttempts'] = 0
        
        # إنشاء بيانات الجلسة
        session_data = {
            'userId': user['id'],
            'username': user['username'],
            'fullName': user['fullName'],
            'role': user['role'],
            'permissions': user['permissions']
        }
        
        log_activity(user['id'], 'تسجيل دخول ناجح', f'المستخدم {username} سجل دخول بنجاح')
        
        return jsonify({
            'success': True,
            'message': 'تم تسجيل الدخول بنجاح',
            'user': session_data
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    try:
        data = request.get_json()
        user_id = data.get('userId')
        
        if user_id:
            log_activity(user_id, 'تسجيل خروج', 'المستخدم سجل خروج')
        
        return jsonify({'success': True, 'message': 'تم تسجيل الخروج بنجاح'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Routes للمخزون
@app.route('/api/inventory', methods=['GET'])
def get_inventory():
    try:
        return jsonify({'success': True, 'data': mock_data['inventory']})
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/inventory', methods=['POST'])
def add_inventory_item():
    try:
        data = request.get_json()
        
        # إنشاء عنصر جديد
        new_item = {
            'id': len(mock_data['inventory']) + 1,
            'name': data['name'],
            'category': data['category'],
            'brand': data.get('brand', ''),
            'size': data.get('size', ''),
            'color': data.get('color', ''),
            'quantity': int(data['quantity']),
            'minQuantity': int(data.get('minQuantity', 10)),
            'maxQuantity': int(data.get('maxQuantity', 100)),
            'location': data.get('location', ''),
            'supplier': data.get('supplier', ''),
            'cost': float(data.get('cost', 0)),
            'price': float(data['price']),
            'currency': data.get('currency', 'SYP'),
            'barcode': data.get('barcode', ''),
            'description': data.get('description', ''),
            'status': 'متوفر' if int(data['quantity']) > int(data.get('minQuantity', 10)) else 'مخزون منخفض',
            'createdAt': datetime.now().strftime('%Y-%m-%d'),
            'updatedAt': datetime.now().strftime('%Y-%m-%d'),
            'expiryDate': data.get('expiryDate'),
            'weight': float(data.get('weight', 0)),
            'dimensions': data.get('dimensions', ''),
            'tags': data.get('tags', '')
        }
        
        mock_data['inventory'].append(new_item)
        
        # تسجيل النشاط
        log_activity(data.get('userId'), 'إضافة صنف', f'تم إضافة صنف جديد: {new_item["name"]}')
        
        return jsonify({'success': True, 'message': 'تم إضافة الصنف بنجاح', 'data': new_item})
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/inventory/<int:item_id>', methods=['PUT'])
def update_inventory_item(item_id):
    try:
        data = request.get_json()
        
        # البحث عن العنصر
        item = None
        for i, inv_item in enumerate(mock_data['inventory']):
            if inv_item['id'] == item_id:
                item = inv_item
                break
        
        if not item:
            return jsonify({'success': False, 'message': 'الصنف غير موجود'}), 404
        
        # تحديث البيانات
        item.update({
            'name': data.get('name', item['name']),
            'category': data.get('category', item['category']),
            'brand': data.get('brand', item['brand']),
            'size': data.get('size', item['size']),
            'color': data.get('color', item['color']),
            'quantity': int(data.get('quantity', item['quantity'])),
            'minQuantity': int(data.get('minQuantity', item['minQuantity'])),
            'maxQuantity': int(data.get('maxQuantity', item['maxQuantity'])),
            'location': data.get('location', item['location']),
            'supplier': data.get('supplier', item['supplier']),
            'cost': float(data.get('cost', item['cost'])),
            'price': float(data.get('price', item['price'])),
            'currency': data.get('currency', item['currency']),
            'barcode': data.get('barcode', item['barcode']),
            'description': data.get('description', item['description']),
            'updatedAt': datetime.now().strftime('%Y-%m-%d'),
            'expiryDate': data.get('expiryDate', item['expiryDate']),
            'weight': float(data.get('weight', item['weight'])),
            'dimensions': data.get('dimensions', item['dimensions']),
            'tags': data.get('tags', item['tags'])
        })
        
        # تحديث الحالة
        item['status'] = 'متوفر' if item['quantity'] > item['minQuantity'] else 'مخزون منخفض'
        
        # تسجيل النشاط
        log_activity(data.get('userId'), 'تحديث صنف', f'تم تحديث الصنف: {item["name"]}')
        
        return jsonify({'success': True, 'message': 'تم تحديث الصنف بنجاح', 'data': item})
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/inventory/<int:item_id>', methods=['DELETE'])
def delete_inventory_item(item_id):
    try:
        # البحث عن العنصر وحذفه
        for i, item in enumerate(mock_data['inventory']):
            if item['id'] == item_id:
                deleted_item = mock_data['inventory'].pop(i)
                
                # تسجيل النشاط
                log_activity(request.get_json().get('userId') if request.get_json() else None, 
                           'حذف صنف', f'تم حذف الصنف: {deleted_item["name"]}')
                
                return jsonify({'success': True, 'message': 'تم حذف الصنف بنجاح'})
        
        return jsonify({'success': False, 'message': 'الصنف غير موجود'}), 404
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Routes للواردات
@app.route('/api/incoming', methods=['GET'])
def get_incoming():
    try:
        return jsonify({'success': True, 'data': mock_data['incoming']})
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/incoming', methods=['POST'])
def add_incoming():
    try:
        data = request.get_json()
        
        # إنشاء وارد جديد
        new_incoming = {
            'id': len(mock_data['incoming']) + 1,
            'itemId': int(data['itemId']),
            'itemName': data['itemName'],
            'supplier': data['supplier'],
            'size': data.get('size', ''),
            'brand': data.get('brand', ''),
            'quantity': int(data['quantity']),
            'price': float(data['price']),
            'date': data['date'],
            'currency': data.get('currency', 'SYP'),
            'exchangeRate': float(data.get('exchangeRate', 1.0)),
            'paymentMethod': data.get('paymentMethod', 'نقد'),
            'invoiceNumber': data['invoiceNumber'],
            'notes': data.get('notes', ''),
            'status': 'مكتمل',
            'receivedBy': data.get('receivedBy', ''),
            'qualityCheck': data.get('qualityCheck', 'مقبول'),
            'storageLocation': data.get('storageLocation', ''),
            'expiryDate': data.get('expiryDate'),
            'batchNumber': data.get('batchNumber', ''),
            'totalCost': float(data['price']) * int(data['quantity'])
        }
        
        mock_data['incoming'].append(new_incoming)
        
        # تحديث المخزون
        for item in mock_data['inventory']:
            if item['id'] == int(data['itemId']):
                item['quantity'] += int(data['quantity'])
                item['updatedAt'] = datetime.now().strftime('%Y-%m-%d')
                item['status'] = 'متوفر' if item['quantity'] > item['minQuantity'] else 'مخزون منخفض'
                break
        
        # تسجيل النشاط
        log_activity(data.get('userId'), 'إضافة وارد', f'تم إضافة وارد جديد: {new_incoming["itemName"]} - الكمية: {new_incoming["quantity"]}')
        
        return jsonify({'success': True, 'message': 'تم إضافة الوارد بنجاح', 'data': new_incoming})
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Routes للصادرات
@app.route('/api/outgoing', methods=['GET'])
def get_outgoing():
    try:
        return jsonify({'success': True, 'data': mock_data['outgoing']})
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/outgoing', methods=['POST'])
def add_outgoing():
    try:
        data = request.get_json()
        
        # التحقق من توفر الكمية
        item = None
        for inv_item in mock_data['inventory']:
            if inv_item['id'] == int(data['itemId']):
                item = inv_item
                break
        
        if not item:
            return jsonify({'success': False, 'message': 'الصنف غير موجود'}), 404
        
        if item['quantity'] < int(data['quantity']):
            return jsonify({'success': False, 'message': 'الكمية المطلوبة غير متوفرة في المخزون'}), 400
        
        # إنشاء صادر جديد
        new_outgoing = {
            'id': len(mock_data['outgoing']) + 1,
            'itemId': int(data['itemId']),
            'itemName': data['itemName'],
            'customer': data['customer'],
            'size': data.get('size', ''),
            'brand': data.get('brand', ''),
            'quantity': int(data['quantity']),
            'price': float(data['price']),
            'date': data['date'],
            'currency': data.get('currency', 'SYP'),
            'exchangeRate': float(data.get('exchangeRate', 1.0)),
            'paymentMethod': data.get('paymentMethod', 'نقد'),
            'invoiceNumber': data['invoiceNumber'],
            'notes': data.get('notes', ''),
            'status': 'مكتمل',
            'soldBy': data.get('soldBy', ''),
            'deliveryMethod': data.get('deliveryMethod', 'توصيل مباشر'),
            'customerPhone': data.get('customerPhone', ''),
            'customerAddress': data.get('customerAddress', ''),
            'profit': (float(data['price']) - item['cost']) * int(data['quantity']),
            'totalRevenue': float(data['price']) * int(data['quantity'])
        }
        
        mock_data['outgoing'].append(new_outgoing)
        
        # تحديث المخزون
        item['quantity'] -= int(data['quantity'])
        item['updatedAt'] = datetime.now().strftime('%Y-%m-%d')
        item['status'] = 'متوفر' if item['quantity'] > item['minQuantity'] else 'مخزون منخفض'
        
        # إنشاء تنبيه إذا انخفض المخزون
        if item['quantity'] <= item['minQuantity']:
            alert = {
                'id': len(mock_data['alerts']) + 1,
                'type': 'مخزون منخفض',
                'message': f'{item["name"]} - الكمية أقل من الحد الأدنى',
                'itemId': item['id'],
                'itemName': item['name'],
                'currentQuantity': item['quantity'],
                'minQuantity': item['minQuantity'],
                'priority': 'عالية',
                'status': 'نشط',
                'createdAt': datetime.now().strftime('%Y-%m-%d'),
                'acknowledgedBy': None,
                'resolvedAt': None,
                'category': 'مخزون',
                'action': 'طلب شراء جديد'
            }
            mock_data['alerts'].append(alert)
        
        # تسجيل النشاط
        log_activity(data.get('userId'), 'إضافة صادر', f'تم إضافة صادر جديد: {new_outgoing["itemName"]} - الكمية: {new_outgoing["quantity"]}')
        
        return jsonify({'success': True, 'message': 'تم إضافة الصادر بنجاح', 'data': new_outgoing})
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Routes للتنبيهات
@app.route('/api/alerts', methods=['GET'])
def get_alerts():
    try:
        return jsonify({'success': True, 'data': mock_data['alerts']})
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

@app.route('/api/alerts/<int:alert_id>/acknowledge', methods=['PUT'])
def acknowledge_alert(alert_id):
    try:
        data = request.get_json()
        
        # البحث عن التنبيه
        for alert in mock_data['alerts']:
            if alert['id'] == alert_id:
                alert['acknowledgedBy'] = data.get('userId')
                alert['status'] = 'مقروء'
                
                # تسجيل النشاط
                log_activity(data.get('userId'), 'قراءة تنبيه', f'تم قراءة التنبيه: {alert["message"]}')
                
                return jsonify({'success': True, 'message': 'تم تأكيد قراءة التنبيه'})
        
        return jsonify({'success': False, 'message': 'التنبيه غير موجود'}), 404
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Routes للإحصائيات
@app.route('/api/stats', methods=['GET'])
def get_stats():
    try:
        # حساب الإحصائيات
        total_items = len(mock_data['inventory'])
        total_quantity = sum(item['quantity'] for item in mock_data['inventory'])
        low_stock_items = len([item for item in mock_data['inventory'] if item['quantity'] <= item['minQuantity']])
        
        total_incoming = len(mock_data['incoming'])
        total_outgoing = len(mock_data['outgoing'])
        
        total_revenue = sum(out['totalRevenue'] for out in mock_data['outgoing'])
        total_profit = sum(out['profit'] for out in mock_data['outgoing'])
        
        active_alerts = len([alert for alert in mock_data['alerts'] if alert['status'] == 'نشط'])
        
        stats = {
            'inventory': {
                'totalItems': total_items,
                'totalQuantity': total_quantity,
                'lowStockItems': low_stock_items,
                'categories': len(set(item['category'] for item in mock_data['inventory']))
            },
            'transactions': {
                'totalIncoming': total_incoming,
                'totalOutgoing': total_outgoing,
                'totalRevenue': total_revenue,
                'totalProfit': total_profit
            },
            'alerts': {
                'activeAlerts': active_alerts,
                'totalAlerts': len(mock_data['alerts'])
            }
        }
        
        return jsonify({'success': True, 'data': stats})
        
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Routes للمستخدمين
@app.route('/api/users', methods=['GET'])
def get_users():
    try:
        # إخفاء كلمات المرور
        users = []
        for user in mock_data['users']:
            user_copy = user.copy()
            user_copy.pop('password', None)
            users.append(user_copy)
        
        return jsonify({'success': True, 'data': users})
    except Exception as e:
        return jsonify({'success': False, 'message': f'خطأ في الخادم: {str(e)}'}), 500

# Route للصحة
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'success': True, 'message': 'API يعمل بشكل طبيعي', 'timestamp': datetime.now().isoformat()})

# Vercel handler
def handler(request):
    return app(request.environ, lambda status, headers: None)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

